const API_KEY = "AIzaSyC-wr6H1HERa9gHYGF8YD--Y_5APKr-jRE";
        const API_URL = `https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=${API_KEY}`;

        document.getElementById('labTestForm').addEventListener('submit', async function(event) {
            event.preventDefault(); // Prevent default form submission

            const fileInput = document.getElementById('labTestFile');
            const file = fileInput.files[0];

            if (file) {
                const reader = new FileReader();

                reader.onloadend = async function() {
                    const base64Image = reader.result.split(',')[1];
                    
                    try {
                        const response = await fetch(API_URL, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                // Update according to API documentation
                                imageBase64: base64Image, // Example field name
                                prompt: 'Read the image and analyze and decode all the medical terms used and based on that give risks and further medications'
                            })
                        });

                        if (!response.ok) {
                            const errorText = await response.text();
                            throw new Error(`Error ${response.status}: ${errorText}`);
                        }

                        const result = await response.json();
                        document.getElementById('response').textContent = JSON.stringify(result, null, 2); // Display the response
                    } catch (error) {
                        console.error('Error:', error);
                        document.getElementById('response').textContent = `An error occurred: ${error.message}`;
                    }
                };

                reader.readAsDataURL(file);
            } else {
                document.getElementById('response').textContent = 'No file selected.';
            }
        });
