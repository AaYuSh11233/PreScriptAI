document.getElementById('labTestForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const fileInput = document.getElementById('labTestFile');
    const file = fileInput.files[0];

    if (!file) {
        alert('Please select a file.');
        return;
    }

    const reader = new FileReader();
    reader.onloadend = function() {
        Tesseract.recognize(
            reader.result,
            'eng', // Language code
            {
                logger: info => {
                    console.log(info);
                    document.getElementById('resultsInput').value = `Progress: ${Math.round(info.progress * 100)}%`; // Display progress
                }
            }
        ).then(({ data: { text } }) => {
            document.getElementById('resultsInput').value = text;
        }).catch(error => {
            console.error('Error during OCR processing:', error);
            document.getElementById('resultsInput').value = 'Failed to process the image.';
        });
    };

    reader.readAsDataURL(file); // Read file as data URL
});