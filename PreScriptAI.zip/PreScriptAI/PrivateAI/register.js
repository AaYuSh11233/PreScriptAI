document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const email = document.getElementById('email').value.trim();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
  
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const emailError = document.getElementById('emailError');
    const usernameError = document.getElementById('usernameError');
    const passwordError = document.getElementById('passwordError');
    
    let isValid = true;
  
    emailError.textContent = '';
    usernameError.textContent = '';
    passwordError.textContent = '';
    
    if (!emailPattern.test(email)) {
      emailError.textContent = 'Please enter a valid email address.';
      isValid = false;
    }
    if (username.length < 3) {
      usernameError.textContent = 'Username must be at least 3 characters long.';
      isValid = false;
    }
    if (password.length < 8) {
      passwordError.textContent = 'Password must be at least 8 characters long.';
      isValid = false;
    }
    
    if (!isValid) return;
  
    let users = JSON.parse(localStorage.getItem('users')) || [];
  
    if (users.find(user => user.username === username)) {
      usernameError.textContent = 'Username already exists.';
      isValid = false;
    }
    if (users.find(user => user.email === email)) {
      emailError.textContent = 'Email already exists.';
      isValid = false;
    }
  
    if (!isValid) return;
    
    users.push({ email, username, password });     
    localStorage.setItem('users', JSON.stringify(users));       
    document.querySelector('.wrapper').classList.add('wrapper-hidden');
    document.getElementById('successPopup').classList.remove('hidden');
  
    document.getElementById('popupCloseBtn').addEventListener('click', function() {
      document.getElementById('successPopup').classList.add('hidden');
      document.querySelector('.wrapper').classList.remove('wrapper-hidden');
      window.location.href = 'login.html';
    });
  });

  