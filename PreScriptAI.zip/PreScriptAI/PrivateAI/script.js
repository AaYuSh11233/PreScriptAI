// BMI Calculation //

document.getElementById('height').addEventListener('input', calculateBMI);
document.getElementById('weight').addEventListener('input', calculateBMI);

function calculateBMI() {
    var height = parseFloat(document.getElementById('height').value);
    var weight = parseFloat(document.getElementById('weight').value);

    if (height > 0 && weight > 0) {
        var bmi = weight / (height * height);
        document.getElementById('bmi').value = bmi.toFixed(2);
    } else {
        document.getElementById('bmi').value = '';
    }
}

// Form Submission

document.getElementById('generatePDF').addEventListener('click', async () => {
    // Access jsPDF from the global scope
    const { jsPDF } = window.jspdf;

    // Check if jsPDF is available
    if (!jsPDF) {
        console.error('jsPDF library is not loaded.');
        return;
    }

    // Create a new PDF document
    const doc = new jsPDF();
    const margin = 10; // Margin from the right edge
    const bottomMargin = 20; // Margin from the bottom edge
    const yStart = 20; // Starting vertical position for text

    // Load an image for the background
    const img = new Image();
    img.src = 'pdf-back-1.jpg'; // Replace with your image path

    img.onload = function() {
        // Add background image to the PDF
        function addBackground() {
            doc.addImage(img, 'JPEG', 0, 0, doc.internal.pageSize.width, doc.internal.pageSize.height);
        }

        // Add content to the PDF
        function addContent(startY) {
            // Set font and text properties
            doc.setFontSize(16);
            doc.setFont('Arial', 'bold');
            doc.setTextColor(0, 0, 0); // Black color

            // Text to be right-aligned
            const username = sessionStorage.getItem('username') || 'Dr. ';
            const pageWidth = doc.internal.pageSize.width;
            const textWidth = doc.getTextWidth(text);
            const xPosition = pageWidth - textWidth - margin;
            const yPosition = startY; // Starting position for text

            // Add text to the PDF
            doc.text(username, xPosition, yPosition);

            // Add the prescription text
            doc.setFontSize(12);
            const prescriptionText = document.getElementById('prescriptionInput').value;
            const lines = doc.splitTextToSize(prescriptionText, pageWidth - 2 * margin);
            let y = yPosition + 20; // Adjust the vertical position for text

            // Check if the content fits the page
            lines.forEach(line => {
                if (y + 10 > doc.internal.pageSize.height - bottomMargin) {
                    // Add a new page if content doesn't fit
                    doc.addPage();
                    addBackground();
                    y = yStart + 20; // Reset y position for new page
                }
                doc.text(line, margin, y);
                y += 10; // Line height
            });
        }

        addBackground();
        addContent(yStart);

        // Convert PDF to Blob
        const pdfBlob = doc.output('blob');
        const pdfUrl = URL.createObjectURL(pdfBlob);

        // Set the download link
        const downloadLink = document.getElementById('downloadLink');
        downloadLink.href = pdfUrl;

        // Optionally, trigger download immediately
        downloadLink.click();
    };
});

// API Integration

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById("contactForm");
    const prescriptionInput = document.getElementById("prescriptionInput");
    const generatePDFBtn = document.getElementById("generatePDF");
    const downloadLink = document.getElementById("downloadLink");

    const API_KEY = "AIzaSyC-wr6H1HERa9gHYGF8YD--Y_5APKr-jRE";
    const API_URL = `https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=${API_KEY}`;

    let formData;

    const handleFormSubmit = async (event) => {
        event.preventDefault();

        formData = new FormData(form);
        const data = Object.fromEntries(formData);

        const promptText = `
            As a doctor, I have a patient with the following information:

            - Name: ${data.name}
            - Age: ${data.age}
            - Gender: ${data.gender}
            - Height: ${data.height} meters
            - Weight: ${data.weight} kg
            - BMI: ${data.bmi}
            - Chronic Disease: ${data.disease}
            - Regular Medications: ${data.medications}
            - Current Symptoms: ${data.symptoms}
            - Remarks: ${data.message}

            Please provide a diagnosis based on this information must be 2/3 words answer and should not exceed 10 words. Additionally:
            - Identify perfectly without any error every possible disease related to current symptoms input and suggest medications for those every related diease of the current condition input and will also suggest lab test to perfectly identify the main disease and till further identification through suitable lab test it will give medications/medicines with time and dosage to ease the condition for time being and the medications/medicine to ease the condition must be suitable for all the possible disease related to the current symptom input and should not bear any health related risks.
            - Suggest any necessary lab tests or imaging studies for further investigation lab tests must be in one word and the use of the test.
            - Prescribe suitable medication(s), if required, with clear dosage instructions must provide generic drug name and its words in 6/8 words.
            - Recommend any relevant yoga poses or exercises if required that could be beneficial for the patient's condition the uses of yogas must be in less than 8 words.
            - And if medicines are provided the clearly write about its doses time time to intake the medicines and prequations  
            properly.                                                                                                       
            - And if multiple medicines are provided then clearly write about its prequations alerts if taken consecutively and everything related to this    
            point.                                                                           
            - And if given BMI is low or below average/high according to height weight and age then give an indian diet plan based on the provided BMI.
            Here double check every points in the given prompt before giving response and give answer without any error then answer properly.
            - remove all asterisks and bullet points
        `;

        const requestOptions = {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                contents: [{ role: "user", parts: [{ text: promptText }] }]
            })
        };

        try {
            const response = await fetch(API_URL, requestOptions);
            if (!response.ok) {
                throw new Error(`API response error: ${response.status} ${response.statusText}`);
            }
            const result = await response.json();
            if (result.candidates && result.candidates[0].content && result.candidates[0].content.parts[0]) {
                prescriptionInput.value = result.candidates[0].content.parts[0].text;
            } else {
                prescriptionInput.value = "Unexpected response format.";
            }
        } catch (error) {
            console.error("Error generating prescription:", error);
            prescriptionInput.value = "Oops! Something went wrong. Please try again.";
        }
    };

    const generatePDF = () => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const margin = 10;
        const bottomMargin = 10;
        const yStart = 50; // Adjusted to account for header and top margin
        const pageWidth = doc.internal.pageSize.width;
        const pageHeight = doc.internal.pageSize.height;
        const titleHeight = 20; // Height for the title section to avoid text interference

        // Load background image
        const backgroundImgBase64 = 'back.png'; // Replace <BASE64_IMAGE> with your actual base64 string

        const addBackground = () => {
            doc.addImage(backgroundImgBase64, 'PNG', 0, 0, pageWidth, pageHeight);
        };

        const addContent = (startY) => {
            doc.setFontSize(16);
            doc.setFont('Arial', 'bold');
            doc.setTextColor(0, 0, 0); // Black color

            const title = 'Dr. x';
            const textWidth = doc.getTextWidth(title);
            const xPosition = pageWidth - textWidth - margin;
            const yPosition = startY;

            doc.text(title, xPosition, yPosition);

            doc.setFontSize(12);

            // Add biodata section
            const bioDataLines = [
                `Name: ${formData.get('name')}`,
                `Age: ${formData.get('age')}    Gender: ${formData.get('gender')}   Height: ${formData.get('height')} meters    Weight: ${formData.get('weight')} kg  BMI: ${formData.get('bmi')}`,
                `Chronic Disease: ${formData.get('disease')}    Regular Medications: ${formData.get('medications')}`,
                "",
            ];

            let y = yPosition + titleHeight + 10;
            bioDataLines.forEach(line => {
                if (y + 10 > pageHeight - bottomMargin) {
                    doc.addPage();
                    addBackground();
                    y = yStart;
                }
                doc.text(line, margin, y);
                y += 10;
            });

            // Add the Gemini response
            const responseText = prescriptionInput.value;
            const lines = doc.splitTextToSize(responseText, pageWidth - 2 * margin);
            lines.forEach(line => {
                if (y + 10 > pageHeight - bottomMargin) {
                    doc.addPage();
                    addBackground();
                    y = yStart;
                }
                doc.text(line, margin, y);
                y += 10;
            });
        };

        addBackground();
        addContent(yStart);

        const pdfBlob = doc.output('blob');
        const pdfUrl = URL.createObjectURL(pdfBlob);
        downloadLink.href = pdfUrl;
        downloadLink.click();
    };

    form.addEventListener("submit", handleFormSubmit);
    generatePDFBtn.addEventListener("click", generatePDF);
});


