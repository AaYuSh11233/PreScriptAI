document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
  
    const usernameError = document.getElementById('loginUsernameError');
    const passwordError = document.getElementById('loginPasswordError');
  
    let isValid = true;
  
    usernameError.textContent = '';
    passwordError.textContent = '';
  
    if (username.length === 0) {
        usernameError.textContent = 'Username is required.';
        isValid = false;
    }
    if (password.length === 0) {
        passwordError.textContent = 'Password is required.';
        isValid = false;
    }
  
    if (!isValid) return;
  
    let users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(user => user.username === username && user.password === password);
  
    if (user) {
        localStorage.setItem('currentUser', username);
        document.querySelector('.wrapper').classList.add('wrapper-hidden');
        document.getElementById('successPopup').classList.remove('hidden');
      
        document.getElementById('popupCloseBtn').addEventListener('click', function() {
        document.getElementById('successPopup').classList.add('hidden');
        document.querySelector('.wrapper').classList.remove('wrapper-hidden');
        window.location.href = 'dr.html';
  
        });
        
    } else {
        alert('Invalid username or password.');
    }
  });

  